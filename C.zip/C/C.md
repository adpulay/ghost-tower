# Role 2: Agent and ML (Nemotron + Classifier + Trace Panel)

**You own:** `agent/` (except `tools/predict_route` and `tools/draft_report`), `classifier/`, `web/src/trace-panel/`, the Brev box, and the Twilio account.
**Your job:** make the Nemotron agent genuinely plan, call real tools and re-plan; get T-Mobile's classifier measured against their baseline; and build the screen component that shows the agent thinking.

Read `INTERFACES.md` first. Your tool outputs and reducer calls must match it exactly.

**Estimated load:** ~14 build hours.

### Skills you'll walk away with
- **Model serving:** running an open LLM on a cloud GPU with vLLM and tool calling
- **Applied ML:** fine-tuning or extending a classifier and evaluating it honestly against a baseline
- **Agent engineering:** a plan → tool → re-plan loop with guardrails, timeouts and evals
- **Frontend:** the live trace panel, the piece judges watch most closely
- **Pitching:** narrating the agent live and presenting the Nemotron panel

---

## Phase 0: Start the slow things first (2:20–3:00 PM)

Model downloads and loading take a while. Kick them off *before* the contract meeting.

- [ ] Launch a Brev GPU instance. Nemotron 3 Nano is documented for vLLM on RTX Pro 6000, DGX Spark, H100 and B200; the FP8 or NVFP4 checkpoints are lighter. NVIDIA publishes a Brev launchable for the NVFP4 version, which is the fastest path if it's available to you.
- [ ] Serve it as an OpenAI-compatible API with tool calling turned on. The documented vLLM flags:
  ```bash
  vllm serve --model "nvidia/NVIDIA-Nemotron-Nano-3-30B-A3B-FP8" \
    --dtype auto --trust-remote-code \
    --served-model-name nemotron \
    --host 0.0.0.0 --port 5000 \
    --enable-auto-tool-choice \
    --tool-call-parser qwen3_coder \
    --reasoning-parser deepseek_r1
  ```
  Check the model card / cookbook for the exact current flags; they change.
- [ ] **Fallback:** get an API key for NVIDIA's hosted endpoint (build.nvidia.com) so development isn't blocked if Brev is slow.
- [ ] **Upgrade the Twilio account** (~$20). Trial accounts play a message before calls and can only text verified numbers. Verify all three team phones anyway.
- [ ] Attend the contract meeting; you own §7 (tools) and §8 (classifier) of `INTERFACES.md`.

---

## Phase 1: Classifier (3:00–6:00 PM, while the model loads)

- [ ] Load T-Mobile's provided dataset. Make a fixed train/validation/test split (seeded). Never touch test until the end.
- [ ] Reproduce their baseline numbers on your test split.
- [ ] Improve it with whatever is fastest: fine-tune a small transformer, or add features (brand keywords, link presence, urgency words, alphanumeric sender) to their model. **Time-box to 2 hours.**
- [ ] Add brand detection (simple keyword map is fine: TxTag, NTTA, USPS, Chase, etc.).
- [ ] Expose `POST /score { text } -> { score, brand }` on the Brev box.
- [ ] Write `classifier/results.md`: per-class precision, recall, F1 and confusion matrix, **baseline vs yours**.

### ✅ C1 checklist (6:00 PM)
- [ ] `/score` reachable by Role 1's simulator and Role 3's app
- [ ] `classifier/results.md` has baseline vs improved numbers
- [ ] Nemotron answers a test prompt with a tool call on Brev (or hosted fallback)

---

## Phase 2: Your tools (6:00–7:00 PM)

Implement in `agent/tools/`. Inputs and outputs exactly as `INTERFACES.md` §7. Two tools come from teammates (`predict_route` from Role 1, `draft_report` from Role 3); stub them with fixed outputs until theirs arrive.

| Tool | Real or mock | Notes |
|---|---|---|
| `get_track_context` | Real | Read from Spacetime via the client SDK (TypeScript SDK is official; write the agent service in TS to use it) |
| `rdap_domain_age` | Real for benign domains, **mock for the demo scam domain** | Public RDAP lookup works without a key. **Never** query or visit a real live phishing domain. The demo domain (`*.example`) returns a canned "created 2 days ago". |
| `carrier_smsc_lookup` | Mock | Returns `"no"` for the campaign hash, `"yes"` for benign toll texts. Label it as a mock in the UI. |
| `send_warning` | Real (Twilio) + simulated count | Text only the verified team phones; count simulated phones inside the zone polygon. Message text comes from Role 3's `draft_report(kind="warning")`. |

- [ ] Each of your tools has a unit test with a fixed input and expected output shape.

---

## Phase 3: The agent loop (7:00–9:00 PM)

Run as a long-lived service that **subscribes** to the `track` table.

```
on track update:
  if track.status == "active" and not already investigating(track):
      investigate(track)
  if investigating(track) and heading changed > 45° or prediction stale > 20 s:
      replan(track)
  if track.status == "dormant":
      write_trace(kind="summary", "Track dormant, watching for campaign reappearance")

investigate(track):
  write_trace(plan, "Investigating track #id: grouping campaign, checking origin, predicting route")
  messages = [system_prompt, track_context]
  loop up to 8 steps:
      response = nemotron(messages, tools)
      for each tool_call: write_trace(tool_call, ...); result = run(tool); write_trace(tool_result, short summary)
      stop when the model returns a final summary
  write_trace(summary, ...)
```

**System prompt essentials** (full version in `agent/prompts/system.md`):
- You are investigating a suspected SMS blaster track. You gather evidence and take response actions.
- Always: group the campaign (`rdap_domain_age`, `agent_link_campaign`), check origin (`carrier_smsc_lookup`), predict route (`predict_route` → `agent_set_prediction`), warn the predicted path (`draft_report` warning → `send_warning` → `agent_record_alert`).
- Re-plan when told the track turned.
- **You never decide whether this is a blaster or how confident we are. That comes from the track's `confidence` field. Report evidence only.**
- Each trace line is one sentence a judge can read in 3 seconds.

- [ ] Every tool call and result is written to `agent_trace` via `agent_write_trace`, so it streams to all screens.
- [ ] Cap tool loops (max 8 steps) and add a 20 s timeout per model call.
- [ ] Swap in Role 1's `predict_route` and Role 3's `draft_report` as they arrive.

### ✅ C2 checklist (9:00 PM, with Roles 1 and 3)
- [ ] When Role 1's `demo-01` track goes active, trace lines appear within ~10 s
- [ ] A prediction path and intercept point appear on the map
- [ ] A real warning text arrives on a verified team phone
- [ ] After the Coit Rd turn, a `replan` trace line appears and the prediction updates

---

## Phase 4: Trace panel component (9:00–11:00 PM)

`web/src/trace-panel/`, a component Role 3 drops into the analyst map's side panel. You build it because you know exactly what the agent writes.

- [ ] Subscribes to `agent_trace` for the selected track; auto-scrolls; newest at the bottom.
- [ ] Visual style by `kind`: plan, tool call, tool result, re-plan, summary. Re-plan lines should stand out; that's the moment judges should notice.
- [ ] Tool results that came from a mock (carrier lookup) get a small "simulated" tag.
- [ ] Short header: track number, status and confidence (read from `track`, not computed).
- [ ] Merge only after it renders inside Role 3's shell without changing their files.

---

## Phase 5: Evals (11:00 PM–2:00 AM)

- [ ] **Agent scenario evals:** for each attack scenario in `TESTING.md`, define the required tool set. Run each 5–10×. Record:
  - required tools all called? (yes/no)
  - re-planned after turn? (yes/no)
  - claimed to set `confidence`/`status`? (must be **never**; it physically can't via the reducers, so this checks prompt behavior in the trace)
  - time to first prediction (s)
- [ ] Write `agent/results.md` with success rates.
- [ ] Sanity-check Role 1's fusion ablation conclusions.

### ✅ C4 checklist (2:00 AM)
- [ ] `classifier/results.md`, `agent/results.md` done
- [ ] Your Nemotron panel written (see Phase 6)

---

## Phase 6: Your pitch panel + hardening (2:00–8:00 AM)

- [ ] **Write the Nemotron panel** of the track slide yourself (3 bullets max): plan → tools → re-plan, which tools are real, agent success rate. Also send Role 3 the classifier vs baseline line for the T-Mobile panel, and the 3 best trace lines for the slide.
- [ ] **Record a full agent trace** from a clean `demo-01` run to `agent/replay/demo-01.json`, plus a replay mode that writes it back with original timing. This is your fallback if Brev dies mid-demo.
- [ ] Switching between Brev and the hosted endpoint is a single env variable.
- [ ] Warm the model right before judging (send one dummy request) so the first real call isn't slow.
- [ ] Rehearse your demo part: narrating the trace panel in about 30 seconds.

---

## Reintegration (how your work merges back)

**At every checkpoint:**
1. Pull `main`, rebase `role2/*`, run the agent against a fresh `reset_world` + `sim run demo-01`.
2. If clean, merge and post "Role 2 merged @ C#" with one line on what changed.
3. **If a tool's output shape changes,** announce first and update `INTERFACES.md` §7 in the same commit.
4. **Teammates' tools:** when Role 1's `predict_route` or Role 3's `draft_report` arrives, run its unit test, wire it in, and confirm with a full run before merging.

**Integration responsibilities:**
- You own the go/no-go call on **live model vs replay** before judging.
- You keep `.env` (Brev URL, hosted key, Twilio creds, verified numbers) out of git and share it privately.

**What you hand to others:**
| To | What | When |
|---|---|---|
| Role 1 + 3 | `/score` endpoint or cached scores | 6:00 PM |
| Role 1 + 3 | agent writing trace/prediction/alert | 9:00 PM |
| Role 3 | trace panel merged | 11:00 PM |
| Role 3 | Nemotron panel, classifier line, best trace lines | 2:00 AM |

**What you need from others:**
| From | What | When |
|---|---|---|
| Role 1 | live schema + host | 4:30 PM |
| Role 3 | web app shell + shared Spacetime client hook | 6:00 PM |
| Role 1 | `predict_route` function | 9:00 PM |
| Role 3 | `draft_report` function | 9:00 PM |
| Role 1 | tracks that reach `active` | 9:00 PM |
