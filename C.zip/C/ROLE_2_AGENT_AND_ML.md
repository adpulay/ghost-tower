# Role 2: Agent and ML (Nemotron + Classifier + Tools)

**You own:** `agent/`, `classifier/`, the Brev box, and the Twilio account.
**Your job:** make the Nemotron agent genuinely plan, call real tools and re-plan, and get T-Mobile's classifier beating (or at least measured against) their baseline.

Read `INTERFACES.md` first. Your tool outputs and reducer calls must match it exactly.

---

## Phase 0: Start the slow things first (2:20–3:00 PM)

Model downloads and loading take a while. Kick them off *before* the contract meeting.

- [ ] Launch a Brev GPU instance. Nemotron 3 Nano is documented for vLLM on RTX Pro 6000, DGX Spark, H100 and B200; the FP8 or NVFP4 checkpoints are lighter. NVIDIA publishes a Brev launchable for the NVFP4 version, which is the fastest path if it's available to you.
- [ ] Serve it as an OpenAI-compatible API with tool calling turned on. The documented vLLM flags:
  ```bash
  vllm serve --model "nvidia/NVIDIA-Nemotron-Nano-3-30B-A3B-FP8" \
    --dtype auto --trust-remote-code \
    --served-model-name nemotron \
    --host 0.0.0.0 --port 5000 \
    --enable-auto-tool-choice \
    --tool-call-parser qwen3_coder \
    --reasoning-parser deepseek_r1
  ```
  Check the model card / cookbook for the exact current flags; they change.
- [ ] **Fallback:** get an API key for NVIDIA's hosted endpoint (build.nvidia.com) so development isn't blocked if Brev is slow.
- [ ] **Upgrade the Twilio account** (~$20). Trial accounts play a message before calls and can only text verified numbers. Verify all three team phones anyway.
- [ ] Attend the contract meeting; you own §7 (tools) and §8 (classifier) of `INTERFACES.md`.

---

## Phase 1: Classifier (3:00–6:00 PM, while the model loads)

- [ ] Load T-Mobile's provided dataset. Make a fixed train/validation/test split (seeded). Never touch test until the end.
- [ ] Reproduce their baseline numbers on your test split.
- [ ] Improve it with whatever is fastest: fine-tune a small transformer, or add features (brand keywords, link presence, urgency words, alphanumeric sender) to their model. Time-box to 2 hours.
- [ ] Add brand detection (simple keyword map is fine: TxTag, NTTA, USPS, Chase, etc.).
- [ ] Expose `POST /score { text } -> { score, brand }` on the Brev box.
- [ ] Write `classifier/results.md`: per-class precision, recall, F1 and confusion matrix, **baseline vs yours**.

### ✅ C1 checklist (6:00 PM)
- [ ] `/score` reachable by Role 1's simulator and Role 3's app
- [ ] `classifier/results.md` has baseline vs improved numbers
- [ ] Nemotron answers a test prompt with a tool call on Brev (or hosted fallback)

---

## Phase 2: Tools (6:00–7:30 PM)

Implement in `agent/tools/`. Inputs and outputs exactly as `INTERFACES.md` §7.

| Tool | Real or mock | Notes |
|---|---|---|
| `get_track_context` | Real | Read from Spacetime via the client SDK (TypeScript SDK is official; write the agent service in TS to use it) |
| `rdap_domain_age` | Real for benign domains, **mock for the demo scam domain** | Public RDAP lookup works without a key. **Never** query or visit a real live phishing domain. The demo domain (`*.example`) returns a canned "created 2 days ago". |
| `carrier_smsc_lookup` | Mock | Returns `"no"` for the campaign hash, `"yes"` for benign toll texts. Label it as a mock in the UI. |
| `predict_route` | Real | Snap the track to the road network with a public routing API (e.g. OSRM) and project forward `speed × horizon`. If the API is rate-limited, fall back to straight-line projection along `heading_deg`. |
| `send_warning` | Real (Twilio) + simulated count | Text only the verified team phones; count simulated phones inside the zone polygon. |
| `draft_report` | LLM | Short police brief or registrar abuse report generated from the trace. |

- [ ] Each tool has a unit test with a fixed input and expected output shape.

---

## Phase 3: The agent loop (7:30–9:00 PM)

Run as a long-lived service that **subscribes** to the `track` table.

```
on track update:
  if track.status == "active" and not already investigating(track):
      investigate(track)
  if investigating(track) and heading changed > 45° or prediction stale > 20 s:
      replan(track)
  if track.status == "dormant":
      write_trace(kind="summary", "Track dormant, watching for campaign reappearance")

investigate(track):
  write_trace(plan, "Investigating track #id: grouping campaign, checking origin, predicting route")
  messages = [system_prompt, track_context]
  loop up to 8 steps:
      response = nemotron(messages, tools)
      for each tool_call: write_trace(tool_call, ...); result = run(tool); write_trace(tool_result, short summary)
      stop when the model returns a final summary
  write_trace(summary, ...)
```

**System prompt essentials** (put the full version in `agent/prompts/system.md`):
- You are investigating a suspected SMS blaster track. You gather evidence and take response actions.
- Always: group the campaign (`rdap_domain_age`, `agent_link_campaign`), check origin (`carrier_smsc_lookup`), predict route (`predict_route` → `agent_set_prediction`), warn the predicted path (`send_warning` → `agent_record_alert`).
- Re-plan when told the track turned.
- **You never decide whether this is a blaster or how confident we are. That comes from the track's `confidence` field. Report evidence only.**
- Each trace line is one sentence a judge can read in 3 seconds.

- [ ] Every tool call and result is written to `agent_trace` via `agent_write_trace`, so it streams to all screens.
- [ ] Cap tool loops (max 8 steps) and add a 20 s timeout per model call.

### ✅ C2 checklist (9:00 PM, with Roles 1 and 3)
- [ ] When Role 1's `demo-01` track goes active, trace lines appear on Role 3's map within ~10 s
- [ ] A prediction path and intercept point appear on the map
- [ ] A real warning text arrives on a verified team phone
- [ ] After the Coit Rd turn, a `replan` trace line appears and the prediction updates

---

## Phase 4: Evals (9:00 PM–2:00 AM)

- [ ] **Agent scenario evals:** for each scenario in `TESTING.md`, define the required tool set. Run each 5–10×. Record:
  - required tools all called? (yes/no)
  - re-planned after turn? (yes/no)
  - wrote to `confidence`/`status`? (must be **never**; it physically can't via the reducers, so this checks prompt behavior in the trace)
  - total time to first prediction (s)
- [ ] Write `agent/results.md` with success rates.
- [ ] Pair with Role 1 on the **fusion ablation** (text only / rat_drop only / both / all three).

### ✅ C4 checklist (2:00 AM)
- [ ] `classifier/results.md`, `agent/results.md` done
- [ ] Ablation numbers in `eval/results.md` (Role 1's file)
- [ ] Numbers sent to Role 3

---

## Phase 5: Hardening (2:00–8:00 AM)

- [ ] **Record a full agent trace** from a clean `demo-01` run to `agent/replay/demo-01.json`, plus a replay mode that writes it back with original timing. This is your fallback if Brev dies mid-demo.
- [ ] Switching between Brev and the hosted endpoint is a single env variable.
- [ ] Warm the model right before judging (send one dummy request) so the first real call isn't slow.

---

## Reintegration (how your work merges back)

**At every checkpoint:**
1. Pull `main`, rebase `role2/*`, run the agent against a fresh `reset_world` + `sim run demo-01`.
2. If clean, merge and post "Role 2 merged @ C#" with one line on what changed.
3. **If a tool's output shape changes,** announce first and update `INTERFACES.md` §7 in the same commit.

**Integration responsibilities:**
- You own the go/no-go call on **live model vs replay** before judging.
- You keep `.env` (Brev URL, hosted key, Twilio creds, verified numbers) out of git and share it privately.

**What you hand to others:**
| To | What | When |
|---|---|---|
| Role 1 | `/score` endpoint or cached scores | 6:00 PM |
| Role 1 + 3 | agent writing trace/prediction/alert | 9:00 PM |
| Role 3 | classifier + agent numbers | 2:00 AM |
| Role 3 | 3 best trace lines for the slide | 2:00 AM |

**What you need from others:**
| From | What | When |
|---|---|---|
| Role 1 | live schema + host | 4:30 PM |
| Role 1 | tracks that reach `active` | 9:00 PM |
| Role 3 | map showing trace + prediction | 9:00 PM |
