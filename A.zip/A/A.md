# Role 1: World Builder (Spacetime + Simulator + Tracking + Patrol Tablet)

**You own:** `spacetime/`, `sim/`, `eval/`, `agent/tools/predict_route`, `web/src/patrol/`, and the public GitHub repo.
**You are the backbone.** Everyone else reads from and writes to the world you build. Ship a working schema early, even if the math is rough.

Read `INTERFACES.md` first. Your tables and reducers must match it exactly.

**Estimated load:** ~15 build hours.

### Skills you'll walk away with
- **Real-time backend:** designing tables, reducers and scheduled jobs in a reactive database
- **Geospatial algorithms:** clustering, position smoothing, velocity estimation and route projection
- **Evaluation design:** measuring a system against ground truth and running an ablation study
- **Frontend:** building the patrol tablet view in React + Leaflet
- **Pitching:** presenting the Spacetime panel and driving the live simulation

---

## Phase 0: Setup (2:20–3:00 PM)

- [ ] Create the public GitHub repo with the folder layout from `INTERFACES.md` §1. Add the other two as collaborators.
- [ ] Install the Spacetime CLI and create the project (the `spacetime dev` template sets up a module and a React client; keep only the module in `spacetime/`).
- [ ] Redeem the Maincloud credit (code from the leaflet) so you can host a shared instance the whole team connects to.
- [ ] Lead the 30–45 min contract meeting. Write any changes into `INTERFACES.md` and push to `main`.

**Hand-off at 3:00 PM:** repo URL + the Spacetime database name/host posted in team chat.

---

## Phase 1: Schema and stubs (3:00–4:30 PM)

Goal: other roles can connect and see data *before* the real math exists.

- [ ] Create all tables from `INTERFACES.md` §2.
- [ ] Implement `report_anomaly` with the fusion formula (§4). This one is simple; do it for real.
- [ ] Implement the `agent_*` reducers and `sim_write_truth` as straight inserts/upserts.
- [ ] Implement `reset_world`.
- [ ] **Stub `recluster`:** for now, put every event with `fusion >= 0.3` into a single track whose position is the average of the last 20 events. Fake but visible.
- [ ] Publish to the shared instance. Post in chat: "Schema live."

**Unblocks:** Role 3 can draw dots; Role 2 can read a track.

---

## Phase 2: Simulator (4:30–6:00 PM)

Write `sim/` as a script that connects as a Spacetime client and calls reducers.

**Inputs:** a scenario file, e.g. `sim/scenarios/demo-01.json`:
```json
{
  "seed": "demo-01",
  "phones": 300,
  "area_bbox": [32.97, -96.78, 33.00, -96.73],
  "blasters": [
    {
      "route": "routes/demo.json",
      "speed_mps": 11,
      "range_m": 500,
      "on_air": [[0, 600]],
      "brand": "TxTag",
      "domain": "txtag-pay-demo.example"
    }
  ],
  "benign": { "handover_rate_per_phone_hr": 6, "real_toll_texts": 5 },
  "tick_ms": 1000
}
```

**Each tick:**
1. Move the blaster along its route (interpolate between route points at `speed_mps`).
2. Write `sim_write_truth` with the true position and `on_air`.
3. For every simulated phone within `range_m` that hasn't been hit in the last 60 s: call `report_anomaly` with `rat_drop=true`, a short `rat_drop_secs` (5–10 s), `sms_score` from the classifier endpoint (or a cached score), the campaign `url_hash`, `smsc_match="no"`, `source="sim"`. Add ±100 m noise before coarsening.
4. Benign noise: random phones occasionally report `rat_drop=false` events, normal toll texts with `smsc_match="yes"`, and short signal dropouts. These must **not** form tracks.

**Seeded randomness.** Same seed = same run, every time. This is your demo insurance.

- [ ] Build `routes/demo.json` from real road points on OpenStreetMap (Campbell Rd east, then a turn onto Coit Rd).
- [ ] Add the other scenarios listed in `TESTING.md` (turns, stop-and-go, off/on, two blasters, low-power walker, benign-only).
- [ ] CLI: `sim run demo-01`, `sim run --speed 4x demo-01`, `sim reset`.

### ✅ C1 checklist (6:00 PM)
- [ ] `sim run demo-01` produces events and truth rows on the shared instance
- [ ] Role 3's map shows the dots moving (confirm with them)
- [ ] `reset_world` clears everything cleanly

---

## Phase 3: Real tracking math (6:00–8:00 PM)

Replace the stub `recluster` (scheduled every 3 s).

```
recent = events where ts within last 120 s and fusion >= 0.3

1. Cluster: group events within 800 m and 120 s (simple greedy:
   for each event, join the nearest existing cluster centroid within 800 m,
   otherwise start a new cluster). Separate clusters by url_hash when
   two campaigns are active.

2. Match clusters to existing tracks by distance (< 1 km from the track's
   predicted position = last position + velocity * dt). New cluster -> new track.

3. Position: weighted centroid of the cluster's events,
   weight = fusion_score * recency, recency = exp(-(now - ts) / 30 s).
   Smooth: new_pos = 0.6 * centroid + 0.4 * predicted_pos.

4. Velocity: from the last two smoothed positions. Clamp speed to 0–40 m/s.

5. Confidence:
   c = min(1, event_count / 10) * mean(fusion_score of cluster events)
   (+0.1 if any event has smsc_match == "no", cap at 1)

6. Status transitions per INTERFACES.md §5.
```

Keep it deterministic; no randomness inside reducers.

### ✅ C1.5 (8:00 PM): Android check
If Role 3's phone app hasn't sent a report yet, **pair with them for up to an hour.** Your simulator already calls `report_anomaly`, so you know exactly what the app needs to send.

---

## Phase 4: `predict_route` tool (8:00–9:00 PM)

You own this tool because it's the same geometry as your tracking math. Role 2's agent calls it; signature in `INTERFACES.md` §7.

```
predict_route(lat, lon, heading_deg, speed_mps, horizon_s):
  1. Try a public routing API (e.g. OSRM): snap the current point to the
     nearest road, then walk along the road in the direction closest to
     heading_deg for speed_mps * horizon_s meters. Sample a point every 15 s.
  2. If the API fails or is rate-limited: straight-line projection along
     heading_deg at speed_mps.
  3. Intercept: pick the path point at ~60–70% of the horizon, so a patrol
     has time to get there. eta_s = time for the blaster to reach it.
```

- [ ] Unit test: fixed input on Campbell Rd heading east → path stays on or near the road.
- [ ] Hand it to Role 2 as a function with the exact signature; they wire it into the agent.

### ✅ C2 checklist (9:00 PM, with Roles 2 and 3)
- [ ] Track appears within ~30 s of the blaster going on air in `demo-01`
- [ ] Track follows the turn onto Coit Rd
- [ ] Benign-only scenario produces **zero** `active` tracks
- [ ] Role 2's agent writes trace rows and a prediction that show on Role 3's map

---

## Phase 5: Patrol tablet (9:00 PM–12:00 AM)

`web/src/patrol/`, a route inside Role 3's web app shell. Ask Role 3 for the shell and the shared Spacetime client hook; you build only the view.

- [ ] Big map zoomed to the active track, camera follows it.
- [ ] Intercept star, ETA countdown, and the predicted route line from the `prediction` table.
- [ ] One status line at the top that updates on each `replan` trace row: *"Target turned north on Coit Rd. Intercept at Coit & Arapaho, ~3 min."*
- [ ] No agent trace here; the officer only needs where to go.
- [ ] Large touch targets; it's held by a judge, not a developer.

---

## Phase 6: Eval + ablation (12:00–2:00 AM)

`eval/run_eval`. Reads `sim_truth`, `track`, `anomaly_event`, `alert` after a run and prints:

| Metric | How to compute |
|---|---|
| Time to first alert | first `track.status=active` time − first `on_air` time |
| Time to usable fix | first time track error ≤ 300 m and stays ≤ 300 m for 30 s |
| Location error | per tick, distance(track, truth); report median and p90 |
| Protected before hit | phones in an `alert` zone that received the alert *before* their first anomaly event ÷ phones hit after the alert went out |
| False alarms | `active` tracks in benign-only scenarios per 1,000 phone-hours |
| Event-level precision/recall | events assigned to a track vs. whether they were truly within blaster range |

- [ ] Run every scenario 3× and output a single results table into `eval/results.md`.
- [ ] **You lead the fusion ablation** (text only / 2G drop only / both / all three). Change the weights via a dev reducer or config row, re-run, fill the table in `TESTING.md` §2c. Ask Role 2 to sanity-check the conclusions.

### ✅ C4 checklist (2:00 AM)
- [ ] `eval/results.md` exists with real numbers from ≥3 scenarios
- [ ] Ablation table filled
- [ ] Your Spacetime panel numbers sent to Role 3 (see Phase 7)

---

## Phase 7: Your pitch panel + hardening (2:00–8:00 AM)

- [ ] **Write the Spacetime panel** of the track slide yourself (3 bullets max): one shared world state for every client, tracking math inside reducers, load-test number. Send it to Role 3 to drop into the deck.
- [ ] Load test: 300 → 1,000 → 3,000 simulated phones. Measure `recluster` duration.
- [ ] Local fallback: confirm the module runs on a laptop (local Spacetime) with all clients pointed at it, in case venue Wi-Fi dies.
- [ ] README: how to run sim, module and eval in under 5 commands.
- [ ] Rehearse your demo part: starting `sim run demo-01` and explaining the dots in 20 seconds.

---

## Reintegration (how your work merges back)

**At every checkpoint:**
1. Pull `main`, rebase your `role1/*` branch, run `sim run demo-01` against a fresh `reset_world`.
2. If it runs clean, merge to `main` and post "Role 1 merged @ C#" with one line on what changed.
3. **If you changed a table or reducer signature:** you must have announced it *before* pushing, and update `INTERFACES.md` in the same commit.
4. **Patrol view:** merge only after it builds inside Role 3's shell without changing their files.

**Integration responsibilities:**
- You run the C2 and C4 end-to-end checks (you control the world, so you drive the test).
- You own `reset_world` + seed discipline during rehearsals.
- You're the backup for Role 3's Android work at C1.5.

**What you hand to others:**
| To | What | When |
|---|---|---|
| Role 2 + 3 | DB host/name, live schema | 4:30 PM |
| Role 3 | moving sim data | 6:00 PM |
| Role 2 | `predict_route` function + test | 9:00 PM |
| Role 2 | real tracks crossing the active threshold | 9:00 PM |
| Role 3 | patrol view merged | 12:00 AM |
| Role 3 | `eval/results.md` + your Spacetime panel | 2:00 AM |

**What you need from others:**
| From | What | When |
|---|---|---|
| Role 2 | classifier `/score` endpoint (or cached scores) | 6:00 PM |
| Role 3 | web app shell + shared Spacetime client hook | 6:00 PM |
| Role 2 | agent writing to `agent_*` reducers | 9:00 PM |
