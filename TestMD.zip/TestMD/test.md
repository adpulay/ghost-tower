# Task: Build Ghost Tower's demo and test scaffolding (Role 1)

## Context
Ghost Tower detects SMS blasters (fake cell towers) from phone reports.
Read these first, in the repo root:
- INTERFACES.md — the shared contract. Table and reducer names/fields are FIXED.
- TESTING.md — scenarios and pass conditions.
- spacetime/src/lib.rs — the Spacetime module (tables, reducers, recluster).
- sim/ — the simulator (if it exists yet).

I am Role 1. I own: spacetime/, sim/, eval/, agent/tools/predict_route,
web/src/patrol/. Do NOT edit files outside these folders. If something outside
them must change, write the exact change into HANDOFF.md for its owner.

## The one rule: core vs scaffolding
Everything you build here is SCAFFOLDING: it feeds fake inputs into the real
system or shows debug views. The CORE must not know it is being demoed.
- Add NO demo logic to spacetime/src/ (no special cases for source="sim",
  no lowered thresholds, no demo flags).
- Scaffolding lives only in sim/ and in web/src/patrol/ behind ?debug=1.
- Every fake input enters through the same reducer real phones use
  (report_anomaly) or through the real Android app.
- With no flags (no --emulator, no ?debug=1) the system must behave exactly as
  in production.

## Deliverables

### 1. Route picker (sim/)
- Three routes in sim/routes/, each a JSON array of [lat, lon] points on real
  roads in Richardson, TX (UTD / Campbell Rd area):
  - demo.json: east on Campbell Rd, then north on Coit Rd
  - alt-west.json: a different route with at least one turn
  - alt-loop.json: a route with two turns
  Use OpenStreetMap road geometry. If you can't fetch it, write the points
  you're confident of, add "note": "UNVERIFIED" to the file, and list it in
  HANDOFF.md.
- CLI (keep existing commands working):
  - `sim run demo-01 --route alt-west`
  - `sim run judge --seed <any string> --route <name>` → scenario id
    "judge-<seed>"; never modifies demo-01
  - `sim routes` → lists names, length in km, number of turns
- Same seed + same route = identical run. Seeded RNG only; no Math.random()
  or equivalent.

### 2. Emulator hook (sim/)
Lets ONE Android emulator running the real Ghost Tower app sit on the route
and be "hit" by the simulated blaster.
- Flag: `sim run <scenario> --emulator <adb-serial> --emulator-at <lat>,<lon>`
- At start: `adb -s <serial> emu geo fix <lon> <lat>` (note: lon first).
- Each tick, if the blaster is on air, within range_m of the emulator's point,
  and the emulator hasn't been hit in the last 60 s:
  1. `adb -s <serial> emu network speed edge` (2G-type connection)
  2. `adb -s <serial> emu sms send 5550100 "<campaign text>"` — text built
     from the scenario's brand and domain. Use ONLY the scenario's
     ".example" demo domain, never a real domain.
  3. After rat_drop_secs (5–10 s, seeded), `adb -s <serial> emu network speed full`
- The simulator must NOT call report_anomaly for the emulator. The app does
  that itself. Log each hit: "emulator hit at t=…".
- After each hit, watch anomaly_event for a new row with source="phone" within
  20 s, and log "emulator report received: id=…, fusion=…" or
  "emulator report MISSING".
- If adb is missing or the emulator is offline: print one warning and run the
  scenario without it. Never crash the demo.
- Runs without --emulator must stay byte-for-byte identical to before.

### 3. Truth overlay (web/src/patrol/TruthOverlay.tsx)
A self-contained React-Leaflet layer Role 3 can mount on the analyst map.
- Subscribes to sim_truth and track via the shared Spacetime client hook. If
  the hook doesn't exist yet, accept the connection as a prop.
- Draws: the true path (dashed line), the true current position (hollow
  ring), and a connector from it to the nearest active track, labeled
  "error: 140 m" (haversine, rounded to 10 m).
- Renders NOTHING unless the URL has ?debug=1 AND prop `revealed` is true.
- Also export a "Reveal ground truth" button (≥ 48 px touch target) that
  toggles `revealed`.
- Add the exact mounting instructions for Role 3 to HANDOFF.md.

### 4. Demo HUD (web/src/patrol/DemoHud.tsx)
Small overlay, same ?debug=1 rule: time since blaster went on air (first
sim_truth row with on_air=true), time to first active track, current error.

### 5. Benign coda
`sim run benign-02 --speed 8x` must exist and match TESTING.md (real toll
texts via the normal network, smsc_match="yes"). End the run by printing
"active tracks: N". It must be 0.

### 6. HANDOFF.md (repo root)
Notes for the other roles, including at least:
- Role 3: how to mount TruthOverlay and DemoHud.
- Role 3: the app's debug trigger must call the SAME detection function a real
  2G drop calls — not write a report directly.
- Role 3: please draw source="phone" reports differently from source="sim"
  (no contract change needed).
- Team: TESTING.md §6 says ?debug=1 is off on the big screen; the planned
  "reveal ground truth" moment needs that line updated. Proposal only.

## Constraints
- Never change INTERFACES.md tables, fields or reducer signatures. If you
  believe one must change, stop and put the proposal in HANDOFF.md.
- sim_truth is never visible without ?debug=1.
- No randomness or network calls inside Spacetime reducers.
- Never write code that transmits radio signals. The blaster is simulated.
- Language: match what sim/ already uses. If sim/ is empty, use TypeScript with
  the Spacetime TypeScript SDK.

## Acceptance checks (run them and report results)
1. `sim run demo-01` twice from reset_world → identical anomaly_event counts.
2. `sim run judge --seed abc --route alt-loop` → a track goes active and
   follows both turns.
3. `sim run benign-02 --speed 8x` → "active tracks: 0".
4. `sim run demo-01 --emulator emulator-5554 --emulator-at <point on route>`
   with the app installed → at least one "emulator report received".
   If no emulator is available to you, run it without one and confirm the
   warning path works instead; say which you did.
5. TruthOverlay and DemoHud render nothing without ?debug=1 (test page or
   unit test under web/src/patrol/).
6. The error label matches a hand-computed haversine distance within 1 m for a
   fixed pair of test points.
7. `git diff` shows no changes to spacetime/src/ or INTERFACES.md.

## Report back
- One line per file: what you built.
- Results of the 7 checks.
- Everything UNVERIFIED, and everything in HANDOFF.md.